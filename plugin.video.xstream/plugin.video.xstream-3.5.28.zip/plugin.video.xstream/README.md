## Mit der Version 3.5.27 wird die Entwicklung durch Team xStream vorläufig Eingestellt!

Wird ein Patch zu einer Seite eingereicht oder ein Scrapper zu einer neuen Seite so wird dies (insofern es sinnvoll ist) weiterhin eingepflegt.
Fixes an Seiten bzw. neue Seiten am besten als PullRequest einreichen (oder auf Gitter)

![xStream logo](https://raw.githubusercontent.com/streamxstream/plugin.video.xstream//nightly/icon.png)


## Willkommen bei xStream für Kodi!

Bei xStream handelt es sich um ein Video-Addon für Kodi, welches das streamen von Filmen und Serien über eine intuitive und optisch ansprechende Benutzeroberfläche ermöglicht. Sowohl der Funktionsumfang von xStream als auch das Angebot an Streaming-Inhalten wird von den beteiligten Entwicklern stetig weiterentwickelt bzw. um neue Webseiten erweitert. Diese werden auch als Site-Plugins bezeichnet, welche auf die eigentlichen Quellen verweisen die für das bereitgestellte Angebot verantworlich sind! 
***

[![Join the chat at https://gitter.im/Lastship_Chat/xStream](https://badges.gitter.im/Lastship_Chat/xStream.svg)](https://gitter.im/Lastship_Chat/xStream?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

### | [FAQ](https://github.com/streamxstream/xStream-FAQ/blob/master/xStream_Anleitung_FAQ.md) | [Forum](https://forum.kodiman.company/viewforum.php?f=42)

